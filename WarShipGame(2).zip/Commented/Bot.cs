﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WarshipGame
{
    // Класс, представляющий бота в игре "Морской бой"
    public class Bot
    {
        // Поля класса, представляющие карты и кнопки игрока и бота
        public int[,] myMap = new int[Form1.mapSize, Form1.mapSize];//создаётся карта бота
        public int[,] enemyMap = new int[Form1.mapSize, Form1.mapSize];//создаётся карта игрока

        public Button[,] myButtons = new Button[Form1.mapSize, Form1.mapSize];//кнопка игрока
        public Button[,] enemyButtons = new Button[Form1.mapSize, Form1.mapSize];//кнопка бота

        // Конструктор класса, принимающий карты и кнопки в качестве параметров
        public Bot(int[,] myMap, int[,] enemyMap, Button[,] myButtons, Button[,] enemyButtons)
        {
            this.myMap = myMap;
            this.enemyMap = enemyMap;
            this.enemyButtons = enemyButtons;
            this.myButtons = myButtons;
        } /*присвоение переданных массивов и кнопок соответствующим полям объекта Bot. 
            Это позволяет объекту Bot иметь доступ к данным карт и кнопок */

        // Проверка, находится ли точка в пределах карты
        public bool IsInsideMap(int i, int j)
        {
            if (i < 0 || j < 0 || i >= Form1.mapSize || j >= Form1.mapSize)
            {
                return false;
            }
            return true;
        }

        // Проверка, пустая ли область карты для размещения корабля
        public bool IsEmpty(int i, int j, int length)
        {
            bool isEmpty = true;

            for (int k = j; k < j + length; k++)
            {
                if (myMap[i, k] != 0)
                {
                    isEmpty = false;
                    break;
                }
            }

            return isEmpty;
        }

        // Расстановка кораблей на карте бота
        public int[,] ConfigureShips()
        {
            // Функция для расстановки кораблей на игровом поле
            // r - объект Random для генерации случайных чисел

            int lengthShip = 4; // Начинаем с корабля длиной 4 клетки
            int cycleValue = 4; // Начальное значение цикла
            int shipsCount = 10; // Общее количество кораблей, которые нужно разместить
            Random r = new Random(); // Инициализация объекта Random для генерации случайных чисел

            int posX = 0;
            int posY = 0;

            // Цикл, пока не разместим все корабли
            while (shipsCount > 0)
            {
                // Цикл для размещения кораблей в зависимости от их длины
                for (int i = 0; i < cycleValue / 4; i++)
                {
                    // Генерация случайных координат для размещения корабля
                    posX = r.Next(1, Form1.mapSize);
                    posY = r.Next(1, Form1.mapSize);

                    // Проверка, чтобы корабль не вышел за границы игрового поля
                    // и не пересекался с другими кораблями
                    while (!IsInsideMap(posX, posY + lengthShip - 1) || !IsEmpty(posX, posY, lengthShip))
                    {
                        posX = r.Next(1, Form1.mapSize);
                        posY = r.Next(1, Form1.mapSize);
                    }

                    // Размещение корабля на игровом поле (обозначение клеток, занятых кораблем)
                    for (int k = posY; k < posY + lengthShip; k++)
                    {
                        myMap[posX, k] = 1; // Помечаем клетки корабля на игровом поле
                    }

                    shipsCount--; // Уменьшаем количество оставшихся кораблей
                    if (shipsCount <= 0) // Если все корабли размещены, выходим из цикла
                        break;
                }
                cycleValue += 4; // Увеличиваем значение цикла для уменьшения длины следующего корабля
                lengthShip--; // Уменьшаем длину следующего корабля
            }
            return myMap; // Возвращаем игровое поле с размещенными кораблями
        }

        // Выстрел компьютера
        public bool Shoot()
        {
            // Функция, реализующая ход компьютера
            // r - объект Random для генерации случайных чисел

            bool hit = false; // Переменная, отражающая попадание
            Random r = new Random(); // Инициализация объекта Random для генерации случайных чисел

            int posX = r.Next(1, Form1.mapSize); // Генерация случайной координаты X выстрела
            int posY = r.Next(1, Form1.mapSize); // Генерация случайной координаты Y выстрела

            // Проверка, чтобы компьютер не стрелял по уже выбранным клеткам
            while (enemyButtons[posX, posY].BackColor == Color.Blue || enemyButtons[posX, posY].BackColor == Color.Gray)
            {
                posX = r.Next(1, Form1.mapSize);
                posY = r.Next(1, Form1.mapSize);
            }

            // Проверка попадания по кораблю игрока
            if (enemyMap[posX, posY] != 0)
            {
                hit = true; // Отмечаем попадание
                enemyMap[posX, posY] = 0; // Помечаем клетку как пораженную
                enemyButtons[posX, posY].BackColor = Color.Blue; // Отображаем попадание на поле
                enemyButtons[posX, posY].Text = "X"; // Отображаем "X" на клетке, показывая попадание
            }
            else
            {
                hit = false; // Если промахнулся, отмечаем это
                enemyButtons[posX, posY].BackColor = Color.Gray; // Отображаем промах на поле
            }

            // Если было попадание, компьютер делает дополнительный выстрел
            if (hit)
                Shoot(); // Рекурсивный вызов функции для дополнительного выстрела

            return hit; // Возвращаем результат выстрела (попадание или промах)
        }
    }
}